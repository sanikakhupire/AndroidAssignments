package com.example.ratingbarex;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    RatingBar ratingBar;
    ProgressBar progressBar;
    Button btnShowRating, btnStartProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ratingBar = findViewById(R.id.ratingBar);
        progressBar = findViewById(R.id.progressBar);
        btnShowRating = findViewById(R.id.btnShowRating);
        btnStartProgress = findViewById(R.id.btnStartProgress);

        // ⭐ EVENT 1: RatingBar Change Event
        ratingBar.setOnRatingBarChangeListener((bar, rating, fromUser) -> {
            if (fromUser) {
                Toast.makeText(MainActivity.this,
                        "Rating Selected: " + rating,
                        Toast.LENGTH_SHORT).show();
            }
        });

        // ⭐ EVENT 2: Button Click to Show Rating
        btnShowRating.setOnClickListener(v -> {
            float rating = ratingBar.getRating();
            Toast.makeText(MainActivity.this,
                    "Final Rating: " + rating,
                    Toast.LENGTH_SHORT).show();
        });

        // ⭐ EVENT 3: ProgressBar Update Event
        btnStartProgress.setOnClickListener(v -> {
            progressBar.setProgress(0);

            new Thread(() -> {
                for (int i = 0; i <= 100; i += 10) {
                    try {
                        Thread.sleep(300);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    int progress = i;

                    runOnUiThread(() -> progressBar.setProgress(progress));
                }
            }).start();
        });
    }
}