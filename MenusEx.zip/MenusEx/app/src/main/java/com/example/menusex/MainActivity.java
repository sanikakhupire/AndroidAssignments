package com.example.menusex;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // 🔹 Create Options Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    // 🔹 Handle Menu Item Click Events
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.menu_add) {
            Toast.makeText(this, "Add Selected", Toast.LENGTH_SHORT).show();
            return true;
        }
        else if (id == R.id.menu_edit) {
            Toast.makeText(this, "Edit Selected", Toast.LENGTH_SHORT).show();
            return true;
        }
        else if (id == R.id.menu_delete) {
            Toast.makeText(this, "Delete Selected", Toast.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}